clc;clear;

img=imread('Image_1.png');
img=im2double(img);
[x,y,z]=size(img);
gray = rgb2gray(img);
img_rep=zeros(2*x,y);

for i=1:x
    img_rep(2*i-1,:)=gray(i,:);
    img_rep(2*i,:)=gray(i,:);
end

fprintf("Before pixel replication:")
[rows,columns]=size(gray)

fprintf("After pixel replication:")
[rows,columns]=size(img_rep)

figure;
subplot(1,2,1);imshow(gray);title('Original Image')
subplot(1,2,2);imshow(img_rep);title('Image after Pixel Replication')
clc;clear;

Un=[1 1 1 1;1 1 1 1;1 1 1 1;1 1 1 1];

N=4;
k=1:N;
n=1:N;
for i=k
    for j=n
        TK(i,j)=(sqrt(2/(N+1))*(sin((i*j*pi)/(N+1))));
    end
end

Vk=TK*Un;

fprintf("Original Matrix:\n")
disp(Un)
fprintf("Transformation Kernel for N=%d:\n",N)
disp(TK)
fprintf("Transformed Matrix:\n")
disp(Vk)
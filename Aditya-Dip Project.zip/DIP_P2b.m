clc;clear;

img=(imread('Image_2.png'));
img=im2double(img);
[x,y,z]=size(img);

N=x;
k=1:N;
n=1:N;
for i=k
    for j=n
        TK(i,j)=(sqrt(2/(N+1))*(sin((i*j*pi)/(N+1))));
    end
end

figure;
img_gray=rgb2gray(img);
subplot(1,3,1);imshow(img);title('Original Image');

img_DST=TK*img_gray;
subplot(1,3,2);imshow(img_DST);title('After DST');

img_IDST=TK'*img_DST;
subplot(1,3,3);imshow(img_IDST);title('After IDST');




DST=TK*img_gray;
figure;imshow(DST);
IDST=TK'*DST;
figure;imshow(IDST);

